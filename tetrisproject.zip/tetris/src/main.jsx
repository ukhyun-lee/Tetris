import React from "react";
import ReactDOM from "react-dom/client";
import Tetris from "./tetris.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Tetris />
  </React.StrictMode>
);
